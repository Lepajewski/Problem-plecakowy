import subprocess
import os

def compile_main(sources_dir, bins_dir, output=False):
    if not os.path.isdir('{}'.format(bins_dir)):    
        os.mkdir('{}'.format(bins_dir))
    for algo in os.listdir(sources_dir):
        if algo == 'main.cpp':
            name = algo.split('.')[0]
            command = ['g++', '-o', '{}/{}'.format(bins_dir, name), '{}/{}'.format(sources_dir, algo)]
            a = subprocess.run(command, capture_output=True)
            print('Executing: {}'.format(' '.join(command)))
            if output:
                print(a.stdout.decode('utf-8'))
                print(a.stderr.decode('utf-8'))
        

def run_code(bins_dir, tests_dir, tests, time_dir, s_t, t_t, t_s, t_n, output=False):
    if not os.path.isdir(time_dir):
        os.mkdir(time_dir)
    os.chdir(time_dir)
    if not os.path.isdir(t_t):
        os.mkdir(t_t)
    os.chdir(t_t)
    os.chdir('..')
    os.chdir('..')
    
    test_file_name = '{}/{}/{}_{}.in'.format(tests_dir, t_t, t_s, t_n)
    time_output_name = '{}/{}/{}_{}.time'.format(time_dir, t_t, t_s, t_n)
    test = open(test_file_name, 'r')
    times = open(time_output_name, 'w')
    command = ['{}/{}'.format(bins_dir, s_t)]
    subprocess.run(command, stdin=test, stdout=times, stderr=None)
    if output:
        print(' '.join(command) + '{} 1>{}'.format(test_file_name, time_output_name))
    test.close()
    times.close()
    

#Projekt na Algorytmy i Struktury Danych - problem plecakowy
#Łukasz Kania, I5

import test_gen
import run_algos
import os
import subprocess
import make_plots
import numpy as np
from matplotlib import pyplot as plt

TEST_SIZES = [i for i in range(5,28)] #liczba elementów
TEST_TYPE = ['increasing', 'constant']
TESTS = 'tests'
NUMBER_OF_TESTS = 1
SOURCES = 'sources'
RESULTS = 'results'
BINS = 'bins'
TIMES = 'times'
NUMBER_RANGE = (0, 100)
INTERVAL_RANGE = (1, 10)
INTERVAL_LENGTH = 10
CUTOFS = {'main':[20, 'increasing', 'constant'], }
COMPILER_OUTPUT = True

 
if not os.path.isdir('{}'.format(TESTS)):
    os.mkdir('{}'.format(TESTS))

#test_gen.increasing(TESTS, TEST_TYPE[0], TEST_SIZES, NUMBER_OF_TESTS)
#test_gen.constant(TESTS, TEST_TYPE[1], TEST_SIZES, NUMBER_OF_TESTS)

#run_algos.compile_main(SOURCES, BINS, COMPILER_OUTPUT)


for algo in os.listdir(BINS):
    if algo == 'main':
        for test_size in TEST_SIZES:
            if algo in CUTOFS and test_size > CUTOFS[algo][0] and 'main' in CUTOFS[algo][1::]:
                break
            #for test_instance in range(NUMBER_OF_TESTS):
             #   run_algos.run_code(BINS, TESTS, TEST_SIZES, TIMES, algo, 'constant', test_size, test_instance, output=COMPILER_OUTPUT)
        make_plots.read_times(TIMES, algo, 'constant', TEST_SIZES, RESULTS, CUTOFS)

print('done')

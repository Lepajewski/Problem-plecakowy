#include <stdlib.h>
#define max(a, b) a > b ? a : b
typedef struct item item;
struct item {int val; int wei;};

long long bruteForce(item *stuff, int s, int n)
{
    long long solution;
    item knapsack;
    int fmax = 0, temp;
    long long aux = (1 << n) - 1;
    do {
        knapsack.val = 0;
        knapsack.wei = 0;
        temp = 1;
        for(int i = 0; i < n; i++){
            if(temp & aux){
                knapsack.val += stuff[i].val;
                knapsack.wei += stuff[i].wei;
            }
            temp <<= 1;
        }
        if(knapsack.wei <= s && knapsack.val > fmax)
        {
            fmax = knapsack.val;
            solution = aux;
        }
        aux--;
    } while(aux);
    return fmax;
}

long long dynamic(item *stuff, int c, int n)
{
    int **Matrix = new int* [n+1];
    for(int i = 0; i <= n; i++)
    {
        Matrix[i] = new int [c+1];
        for(int j = 0; j <= c; j++) 
            Matrix[i][j] = 0;
    }
    for(int i = 1; i <= n; i++)
    {
        for(int j = 1; j <= c; j++)
        {
            Matrix[i][j] = stuff[i-1].wei > j ? Matrix[i-1][j] : max(Matrix[i-1][j], Matrix[i-1][j-stuff[i-1].wei] + stuff[i-1].val);
        }
    }
    return Matrix[n][c]; // Zwrócenie wartości spakowanych elementów
}

int recursive(item *stuff, int c, int n)
{
    if (c <= 0 || n < 0)
        return 0;
    
    int a = stuff[n].val + recursive(stuff, c - stuff[n].wei, n-1);
    int b = recursive(stuff, c, n-1);
    
    return max(a, b);
}

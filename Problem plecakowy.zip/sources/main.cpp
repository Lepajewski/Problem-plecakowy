#include <stdio.h>
#include <time.h>
#include "knapsack.h"

int main()
{
    int n, c;
    clock_t start, end;
    double time;
    item *loot;
    long long ans;
    scanf("%d", &n);
    scanf("%d", &c);
    loot = new item[n];
    
    for(int i = 0; i < n; i++)
    {
        scanf("%d", &loot[i].wei);
        scanf("%d", &loot[i].val);
    }

    start = clock();
    ans = bruteForce(loot, c, n);
    end = clock();
    time = ((double) (end - start)) / CLOCKS_PER_SEC;
    printf("%lf\n", time);
    
    start = clock();
    ans = dynamic(loot, c, n);
    end = clock();
    time = ((double) (end - start)) / CLOCKS_PER_SEC;
    printf("%lf\n", time);
    
    start = clock();
    ans = recursive(loot, c, n);
    end = clock();
    time = ((double) (end - start)) / CLOCKS_PER_SEC;
    printf("%lf\n", time);
    
    return 0;
}

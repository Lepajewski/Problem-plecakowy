import os
from matplotlib import pyplot as plt
import numpy as np

def linear_plt(algo, t_type, TEST_SIZES, times, CUTOFS, results, operation):
    TEST_SIZES = TEST_SIZES[0:len(times)]
    
    x = [i for i in range(5,28)]
    print(x)
    y = times
    plt.plot(x, y, '.')
    
    plt.plot(x, y, label=t_type+', '+str(operation))
    plt.legend()
    os.chdir(results)
    if not os.path.isdir('{}'.format('linearplots')):
        os.mkdir('{}'.format('linearplots'))
    os.chdir('{}'.format('linearplots'))
    if not os.path.isdir('{}'.format(algo)):
        os.mkdir('{}'.format(algo))
    os.chdir('..')
    os.chdir('..')
    plt.xlabel('Liczba elementów')
    plt.ylabel('Czas [s]')
    plt.savefig('{}/{}/{}_{}.pdf'.format(results, 'linearplots', t_type, operation))


def read_times(times_dir, algo_type, test_type, TEST_SIZES, res_dir, CUTOFS):
    if not os.path.isdir('{}'.format(times_dir)):
        os.mkdir('{}'.format(times_dir))
    os.chdir('{}'.format(times_dir))
    if not os.path.isdir('{}'.format(algo_type)):
        os.mkdir('{}'.format(algo_type))
    os.chdir('{}'.format(algo_type))
    os.chdir('..')
    os.chdir('..')
    
    path = '{}/{}'.format(times_dir, test_type)
    print(path)
    if not os.path.isdir('{}'.format(res_dir)):
        os.mkdir(res_dir)
    times1 = []
    times2 = []
    times3 = []
    
    for test in os.listdir(path):
        t = open('{}/{}'.format(path, test), 'r')
        l = 0
        for line in t:
            if l < 3:
                if l == 0:
                    times1.append(float(line))
                if l == 1:
                    times2.append(float(line))
                if l == 2:
                    times3.append(float(line))
            l += 1
        t.close()
    print("TIMES1: ", times1)
    print("TIMES2: ", times2)
    print("TIMES3: ", times3)
    
    linear_plt(algo_type, 'constant', TEST_SIZES, sorted(times1), CUTOFS, res_dir, 'bruteforce')
    linear_plt(algo_type, 'constant', TEST_SIZES, sorted(times2), CUTOFS, res_dir, 'dynamic')
    linear_plt(algo_type, 'constant', TEST_SIZES, sorted(times3), CUTOFS, res_dir, 'recursive')
    plt.clf()

import os
import random as rnd

def increasing(t_dir, t_type, t_sizes, num_of_t):
    os.chdir('{}'.format(t_dir))
    
    if not os.path.isdir('{}'.format(t_type)):
        os.mkdir('{}'.format(t_type))
    os.chdir('{}'.format(t_type))
    
    for i in t_sizes:
        for j in range(num_of_t):
            c = i + rnd.randint(1,i)
            f = open('{}_{}.in'.format(i, j), 'w')
            f.write('{} {}\n'.format(i, c))
            for k in range(i):
                f.write('{} {}\n'.format(rnd.randint(1,c // 2), rnd.randint(1,c))) #waga wartosc
            f.close()
    os.chdir('..')
    os.chdir('..')

def constant(t_dir, t_type, t_sizes, num_of_t):
    os.chdir('{}'.format(t_dir))
    
    if not os.path.isdir('{}'.format(t_type)):
        os.mkdir('{}'.format(t_type))
    os.chdir('{}'.format(t_type))
    
    for i in t_sizes:
        for j in range(num_of_t):
            c = i + rnd.randint(1, i)
            f = open('{}_{}.in'.format(i, j), 'w')
            f.write('{} {}\n'.format(25, i))
            for k in range(25):
                f.write('{} {}\n'.format(rnd.randint(1,c // 2), rnd.randint(1,c))) #waga wartosc
            f.close()
    os.chdir('..')
    os.chdir('..')
